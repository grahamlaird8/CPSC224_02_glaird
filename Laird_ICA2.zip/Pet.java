/********************************
	In Class Assignment #2
	File: Pet.java
	Due: 2/7/19
	Graham Laird
 ********************************/

package ica2;

public class Pet {
	private  String name;
	private  String animal;
	private  int age;
    
	//constructor for Pet to initialize the name, animal and age of the pet.
    public Pet(String nameInput, String animalInput, int ageInput) {
        name = nameInput;
		animal = animalInput;
		age = ageInput;
    }
    
	//setter used to set the name of the object of class pet
	public  void setName(String nameInput)
	{
		name = nameInput;
	}
	
	//setter used to set the animal of the object of class pet
	public  void setAnimal(String animalInput)
	{
		animal = animalInput;
	}
	
	//setter used to set the age of the object of class pet
	public  void setAge(int ageInput)
	{
		age = ageInput;
	}
	
	//getter used to access to name of the object of class pet
	public  String getName()
	{
		return name;
	}
	
	//getter used to access to animal of the object of class pet
	public  String getAnimal()
	{
		return animal;
	}
	
	//getter used to access to age of the object of class pet
	public  int getAge()
	{
		return age;
	}
}