/********************************
	In Class Assignment #2
	File: ICA2.java
	Due: 2/7/19
	Graham Laird
 ********************************/

package ica2;


public class ICA2 {

	/*
	 *Used to test the class Pet. Initializes object frodo to the name Frodo, animal Dog, and age 9. Then demonstrates the getters, and then the setters for those variables.
	 */
    public static void main(String[] args) {
        Pet frodo = new Pet("Frodo", "Dog", 9);
		System.out.println(frodo.getName());
		System.out.println(frodo.getAnimal());
		System.out.println(frodo.getAge());
		frodo.setName("Peewee");
		frodo.setAnimal("Cat");
		frodo.setAge(3);
		System.out.println(frodo.getName());
		System.out.println(frodo.getAnimal());
		System.out.println(frodo.getAge());

    }
    
}
